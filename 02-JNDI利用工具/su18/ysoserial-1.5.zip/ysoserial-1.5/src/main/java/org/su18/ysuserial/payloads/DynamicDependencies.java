package org.su18.ysuserial.payloads;


/**
 * @author mbechler
 */
public interface DynamicDependencies {

}
